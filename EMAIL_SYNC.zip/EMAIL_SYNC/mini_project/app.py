from flask import Flask, redirect, request, jsonify, session, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
from requests_oauthlib import OAuth2Session
import os
import requests
from elasticsearch import Elasticsearch
import logging
from datetime import datetime
from flask_migrate import Migrate


logging.basicConfig(level=logging.DEBUG) 
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['SESSION_COOKIE_NAME'] = 'email_session'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

#Elasticsearch client
# es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
es = Elasticsearch(
    hosts=["http://localhost:9200"],
    request_timeout=60  
)
# OAuth credentials
CLIENT_ID = 'd5ae0704-086a-47c8-8aa5-bc3a096dd538'
# CLIENT_ID = '43068cbb-6389-4b55-af7e-d0128be77b37'
CLIENT_SECRET = 'nNZ8Q~4uVXdXbebJXMmCvf~IaDn4POoKstivbao4'
# CLIENT_SECRET = 'Yzq8Q~zY9~M6iyL4pIGLz~w7a1Gvhp-YCVEEyczW'
AUTHORIZATION_BASE_URL = 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize'
TOKEN_URL = 'https://login.microsoftonline.com/common/oauth2/v2.0/token'
REDIRECT_URI = 'https://localhost:5000/callback'

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    access_token = db.Column(db.String(200), nullable=False)
    refresh_token = db.Column(db.String(200), nullable=True)  # Add refresh token column


# indices for email messages and mailbox details
def create_indices():
    # index for email messages
    es.indices.create(
        index='email_messages',
        ignore=400, 
        body={
            "mappings": {
                "properties": {
                    "user_id": {"type": "keyword"},
                    "email_id": {"type": "keyword"},
                    "subject": {"type": "text"},
                    "from": {"type": "keyword"},
                    "to": {"type": "keyword"},
                    "cc": {"type": "keyword"},
                    "bcc": {"type": "keyword"},
                    "received_date": {"type": "date"},
                    "body": {"type": "text"},
                    "attachments": {
                        "type": "nested",
                        "properties": {
                            "filename": {"type": "keyword"},
                            "filetype": {"type": "keyword"}
                        }
                    }
                }
            }
        }
    )

    # index for mailbox details
    es.indices.create(
        index='mailbox_details',
        ignore=400,
        body={
            "mappings": {
                "properties": {
                    "user_id": {"type": "keyword"},
                    "email_address": {"type": "keyword"},
                    "total_quota": {"type": "long"},
                    "used_quota": {"type": "long"},
                    "folder_structure": {
                        "type": "nested",
                        "properties": {
                            "folder_name": {"type": "keyword"},
                            "message_count": {"type": "integer"}
                        }
                    },
                    "last_sync_date": {"type": "date"}
                }
            }
        }
    )

# create_indices to create the indices
create_indices()



# Indexing
def index_email_message(user_id, email_id, subject, from_address, to_address, cc, bcc, received_date, body, attachments):
    doc = {
        'user_id': user_id,
        'email_id': email_id,
        'subject': subject,
        'from': from_address,
        'to': to_address,
        'cc': cc,
        'bcc': bcc,
        'received_date': received_date,
        'body': body,
        'attachments': attachments
    }
    es.index(index='email_messages', id=email_id, body=doc)

def index_mailbox_details(user_id, email_address, total_quota, used_quota, folder_structure, last_sync_date):
    doc = {
        'user_id': user_id,
        'email_address': email_address,
        'total_quota': total_quota,
        'used_quota': used_quota,
        'folder_structure': folder_structure,
        'last_sync_date': last_sync_date
    }
    es.index(index='mailbox_details', id=user_id, body=doc)

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login')
def login():
    oauth = OAuth2Session(CLIENT_ID, redirect_uri=REDIRECT_URI, scope=['User.Read', 'Mail.Read', 'offline_access'])
    authorization_url, state = oauth.authorization_url(AUTHORIZATION_BASE_URL)
    session['oauth_state'] = state
    return redirect(authorization_url)

@app.route('/callback')
def oauth_callback():
    state = session.get('oauth_state')
    if not state:
        return 'Error: State parameter is missing from session.', 400

    # Initialize OAuth2 session with the client ID and redirect URI
    oauth = OAuth2Session(CLIENT_ID, redirect_uri=REDIRECT_URI, state=state)

    try:
        # Fetch the token
        token = oauth.fetch_token(
            TOKEN_URL,
            authorization_response=request.url,
            client_id=CLIENT_ID
        )
        print("Fetched Token:", token)
    except Exception as e:
        return f'Error fetching token: {str(e)}', 500

    try:
        # Fetch user info
        response = oauth.get('https://graph.microsoft.com/v1.0/me')
        response.raise_for_status()
        user_info = response.json()
        print('User info:', user_info)
    except requests.exceptions.HTTPError as err:
        return f'Error fetching user info: {str(err)} - Response: {response.text}', 500
    except Exception as e:
        return f'Error fetching user info: {str(e)}', 500

    user_email = user_info.get('mail') or user_info.get('userPrincipalName')
    if not user_email:
        return 'Error: User email not found.', 500

    with app.app_context():
        user = User.query.filter_by(email=user_email).first()
        if user is None:
            user = User(
                email=user_email,
                access_token=token.get('access_token'),
                refresh_token=token.get('refresh_token')  # Store refresh token
            )
            db.session.add(user)
            try:
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                return f'Error saving user: {str(e)}', 500

    return redirect(url_for('data_page'))

from requests_oauthlib import OAuth2Session

def refresh_access_token(user_email):
    user = User.query.filter_by(email=user_email).first()
    if not user or not user.refresh_token:
        return None

    oauth = OAuth2Session(CLIENT_ID, token={'access_token': user.access_token, 'refresh_token': user.refresh_token})

    try:
        new_token = oauth.refresh_token(TOKEN_URL)
        user.access_token = new_token.get('access_token')
        user.refresh_token = new_token.get('refresh_token', user.refresh_token)  # Update refresh token if a new one is provided

        db.session.commit()
        return user.access_token
    except Exception as e:
        print(f'Error refreshing token: {str(e)}')
        return None

@app.route('/data')
def data_page():
    with app.app_context():
        users = User.query.all()
    return render_template('data.html', users=users)

@app.route('/sync')
def sync_emails():
    logging.debug("Starting email synchronization...")

    with app.app_context():
        users = User.query.all()
        for user in users:
            logging.debug(f"Syncing emails for user: {user.email}")
            
            oauth = OAuth2Session(CLIENT_ID, token={'access_token': user.access_token, 'refresh_token': user.refresh_token})

            try:
                # Fetch emails
                emails_response = oauth.get('https://graph.microsoft.com/v1.0/me/messages')
                
                if emails_response.status_code == 401: 
                    logging.debug("Access token expired, refreshing...")
                    new_access_token = refresh_access_token(user.email)
                    if new_access_token:
                        oauth = OAuth2Session(CLIENT_ID, token={'access_token': new_access_token, 'refresh_token': user.refresh_token})
                        emails_response = oauth.get('https://graph.microsoft.com/v1.0/me/messages')
                    else:
                        logging.error("Failed to refresh access token.")
                        continue
                
                if emails_response.status_code == 403:
                    logging.error("Access denied: Check permissions and token scopes.")
                    continue

                emails_response.raise_for_status()
                emails = emails_response.json()
                logging.debug("Fetched emails: %s", emails)
                
                # Fetch folder details
                folders_response = oauth.get('https://graph.microsoft.com/v1.0/me/mailFolders')
                if folders_response.status_code == 403:
                    logging.error("Access denied: Check permissions and token scopes.")
                    continue
                
                folders_response.raise_for_status()
                folders = folders_response.json()
                logging.debug("Fetched folders: %s", folders)
                
                # Initialize folder counts
                folder_counts = {folder['displayName']: 0 for folder in folders.get('value', [])}
                
                # Count emails per folder
                folder_ids = {folder['displayName']: folder['id'] for folder in folders.get('value', [])}
                for email in emails.get('value', []):
                    folder_id = email.get('parentFolderId')
                    if folder_id:
                        for folder_name, fid in folder_ids.items():
                            if folder_id == fid:
                                folder_counts[folder_name] += 1

                # Update mailbox details
                mailbox_details = {
                    "total_quota": 100000,
                    "used_quota": 25000,
                    "folder_structure": [
                        {"folder_name": name, "message_count": count} for name, count in folder_counts.items()
                    ],
                    "last_sync_date": datetime.utcnow().isoformat()
                }
                
                logging.debug(f"Updating mailbox details: %s", mailbox_details)
                index_mailbox_details(
                    user_id=user.email,
                    email_address=user.email,
                    **mailbox_details
                )
                
            except requests.exceptions.RequestException as e:
                logging.error("Request failed: %s", str(e))
                continue

    logging.debug("Synchronization complete.")
    
    return '''
    <h1>Synchronization complete</h1>
    <a href="/email_details"><button>View Synced Email Details</button></a>
    '''


@app.route('/email_details')
def all_email_details():
    try:
        # Query Elasticsearch for mailbox details for all users
        mailbox_response = es.search(index='mailbox_details', body={
            "size": 10,  
            "_source": ["user_id", "total_quota", "used_quota", "folder_structure", "last_sync_date"],
            "sort": [{"last_sync_date": {"order": "desc"}}]  # Sort by last_sync_date
        })

        # Extract mailbox details from the response
        mailbox_docs = mailbox_response.get('hits', {}).get('hits', [])
        
        # Query Elasticsearch for email details for all users
        email_response = es.search(index='email_messages', body={
            "size": 10,  
            "_source": ["email_id", "subject", "from", "received_date"],
            "sort": [{"received_date": {"order": "desc"}}]  # Sort by received_date
        })

        # Extract email details from the response
        email_docs = email_response.get('hits', {}).get('hits', [])

    except Exception as e:
        return f'Error fetching details: {str(e)}', 500

    return render_template('email_details.html', mailboxes=mailbox_docs, emails=email_docs)


if __name__ == '__main__':
    with app.app_context():
        # logging.debug('Creating all tables...')
        # db.create_all()
        # logging.debug('Tables created.')
        create_indices()
    app.run(
        host='localhost',
        port=5000,
        ssl_context=('localhost.crt', 'localhost.key')
    )
