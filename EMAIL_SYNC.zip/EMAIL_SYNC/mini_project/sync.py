import requests

def sync_emails(user_id, access_token):
    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
    response = requests.get('https://outlook.office.com/api/v2.0/me/messages', headers=headers)
    
    if response.status_code == 200:
        emails = response.json()['value']
        for email in emails:
            es.index(index='user_emails', id=email['Id'], body=email)
        print(f"Synced {len(emails)} emails for user {user_id}.")
    else:
        print(f"Failed to sync emails for user {user_id}: {response.text}")

# Example usage
user_id = 'user@example.com'
access_token = 'user_access_token'
sync_emails(user_id, access_token)


import time

def fetch_with_retry(url, headers, retries=5, delay=1):
    for _ in range(retries):
        response = requests.get(url, headers=headers)
        if response.status_code == 429:  # Rate limit exceeded
            time.sleep(delay)
            delay *= 2  # Exponential backoff
        else:
            return response
    return response
