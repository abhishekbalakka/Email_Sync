from flask import Flask, redirect, request, session, url_for
from flask_oauthlib.client import OAuth
import os
from elasticsearch import Elasticsearch

# Initialize Flask app and OAuth
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['OAUTH2_CLIENT_ID'] = 'mock-client-id'
app.config['OAUTH2_CLIENT_SECRET'] = 'mock-client-secret'
app.config['OAUTH2_REDIRECT_URI'] = 'http://localhost:5000/oauth/callback'

oauth = OAuth(app)
outlook = oauth.remote_app(
    'outlook',
    consumer_key=app.config['OAUTH2_CLIENT_ID'],
    consumer_secret=app.config['OAUTH2_CLIENT_SECRET'],
    request_token_params={
        'scope': 'email',
    },
    base_url='https://outlook.office.com/api/v2.0/',
    request_token_url=None,
    access_token_url='https://outlook.office.com/api/v2.0/token',
    authorize_url='https://outlook.office.com/api/v2.0/authorize',
)

es = Elasticsearch([{'host': 'localhost', 'port': 9200}])

@app.route('/')
def index():
    return 'Welcome to the Email Engine API'

@app.route('/login')
def login():
    return outlook.authorize(callback=url_for('oauth_callback', _external=True))

@app.route('/oauth/callback')
def oauth_callback():
    response = outlook.authorized_response()
    if response is None or response.get('access_token') is None:
        return 'Access denied: reason={} error={}'.format(
            request.args['error_reason'],
            request.args['error_description']
        )
    
    session['oauth_token'] = (response['access_token'], '')
    user_info = outlook.get('me')
    user_email = user_info.data['mail']
    user_id = save_user(user_email, response['access_token'])
    return redirect(url_for('index'))

@outlook.tokengetter
def get_outlook_oauth_token():
    return session.get('oauth_token')

def save_user(email, token):
    # Example function to save user to Elasticsearch
    user_id = email  # Unique ID for the user, could be email or another unique value
    es.index(index='user_emails', id=user_id, body={'email_id': email, 'token': token})
    return user_id

if __name__ == '__main__':
    app.run(debug=True)
