from elasticsearch import Elasticsearch

# Initialize Elasticsearch client
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])

# Define index settings and mappings
indices = {
    "user_emails": {
        "mappings": {
            "properties": {
                "user_id": {"type": "keyword"},
                "email_id": {"type": "keyword"},
                "email_data": {"type": "object"}
            }
        }
    },
    "mailbox_details": {
        "mappings": {
            "properties": {
                "user_id": {"type": "keyword"},
                "mailbox_info": {"type": "object"}
            }
        }
    }
}

# Create indices
for index_name, index_body in indices.items():
    if not es.indices.exists(index=index_name):
        es.indices.create(index=index_name, body=index_body)
        print(f"Index '{index_name}' created.")
    else:
        print(f"Index '{index_name}' already exists.")
